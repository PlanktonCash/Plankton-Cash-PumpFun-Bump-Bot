export const RPC_URL = ""; // Quicknode or Helius give good rpc urls
export const PRIVATE_KEY = ""; // Your wallet private key to sign transaction
export const TOKEN_ADDRESS = ""; // Token to pump
export const PUBLIC_KEY = "";
